/* SND dashboard (owner: Seba). Every value shown comes from a real /api endpoint. */
"use strict";
const $ = (id) => document.getElementById(id);
const COLORS = {A: "#3b9eff", B: "#2ea66f", C: "#e0a526"};
let weightsDirty = false, holdDecisionUntil = 0;

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
}
async function api(path, method, body) {
  const opt = {method: method || "GET", headers: {}};
  if (body !== undefined) { opt.headers["Content-Type"] = "application/json"; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || ("HTTP " + r.status));
  return data;
}
function toast(msg) { $("toast").textContent = msg; clearTimeout(toast.t); toast.t = setTimeout(() => ($("toast").textContent = ""), 6000); }
async function act(fn, okMsg) {
  try { await fn(); if (okMsg) toast(okMsg); await refresh(); } catch (e) { toast("Error: " + e.message); }
}
const fmt = (v, d = 1, u = "") => (v == null ? "-" : Number(v).toFixed(d) + u);

/* ---------- servers ---------- */
function renderStatus(s) {
  $("activeName").textContent = s.active_name || "NONE";
  $("tickNo").textContent = s.tick;
  const svc = $("svc"); svc.textContent = s.service_state; svc.className = "svc " + s.service_state;
  $("autorun").checked = s.autorun;
  $("servers").innerHTML = s.servers.map((v) => `
    <div class="srv ${v.status}">
      ${v.is_active ? '<span class="active-tag">ACTIVE</span>' : ""}
      <div class="name">${esc(v.name)}</div><div class="reg">${esc(v.region)}</div>
      <span class="badge ${v.status}">${v.status.toUpperCase()}</span>
      <div class="kv" style="margin-top:8px">Latency: <b>${v.up === false ? "no response" : fmt(v.latency_ms, 0, " ms")}</b></div>
      <div class="bar"><i style="width:${v.latency_ms == null ? 0 : Math.min(100, v.latency_ms / 5)}%"></i></div>
      <div class="kv">Load: <b>${fmt(v.load_pct, 0, "%")}</b></div>
      <div class="bar"><i style="width:${v.load_pct || 0}%;background:${(v.load_pct || 0) > 90 ? "#e5484d" : "#3b9eff"}"></i></div>
      <div class="kv">Recent uptime: <b>${fmt(v.recent_uptime * 100, 0, "%")}</b> | cost ${v.cost}</div>
      ${v.injected_fault ? `<div class="fault">Simulated fault: ${esc(v.injected_fault)}</div>` : ""}
    </div>`).join("");
  if (!weightsDirty) renderWeights(s.weights);
}

/* ---------- decision engine ---------- */
function renderDecision(d) {
  const tb = $("decTable").querySelector("tbody");
  if (!d) { tb.innerHTML = ""; $("decSummary").textContent = "No decision yet. Run a scenario."; $("decMeta").textContent = ""; return; }
  $("decMeta").textContent = `decision #${d.id} | tick ${d.tick} | trigger: ${d.trigger} | outcome: ${d.outcome} | computed in ${fmt(d.decision_ms, 2)} ms`;
  $("decSummary").textContent = d.summary;
  tb.innerHTML = d.ranking.map((e) => {
    const c = e.criteria, sel = e.server === d.selected && d.outcome === "failover";
    const cell = (k) => (c[k] ? fmt(c[k].score, 2) : "-");
    return `<tr class="${sel ? "sel" : e.is_current ? "cur" : e.eligible ? "" : "out"}">
      <td>${e.rank}</td><td>${esc(e.name)}</td><td>${esc(e.status)}</td><td><b>${fmt(e.score, 3)}</b></td>
      <td>${cell("latency")}</td><td>${cell("load")}</td><td>${cell("reliability")}</td><td>${cell("cost")}</td><td>${cell("health")}</td>
      <td>${sel ? "SELECTED" : e.is_current ? "current (not a candidate)" : e.eligible ? "alternative" : "excluded: " + esc(e.reason)}</td></tr>`;
  }).join("");
}
function renderWeights(w) {
  const el = $("weights");
  if (el.dataset.ready && document.activeElement && el.contains(document.activeElement)) return;
  el.innerHTML = Object.keys(w).map((k) => `<div><label>${k}: <b id="wv_${k}">${w[k].toFixed(2)}</b>
    <input type="range" min="0" max="1" step="0.05" value="${w[k]}" data-k="${k}"></label></div>`).join("");
  el.dataset.ready = "1";
  el.querySelectorAll("input").forEach((i) => i.addEventListener("input", () => { weightsDirty = true; $("wv_" + i.dataset.k).textContent = Number(i.value).toFixed(2); }));
}

/* ---------- lists ---------- */
function renderAlerts(list) {
  $("alerts").innerHTML = list.length ? list.map((e) => `<li class="${e.level}"><div>${esc(e.message)}</div><div class="t">tick ${e.tick} | ${esc(e.ts)}</div></li>`).join("")
    : '<li class="info">No alerts. Run a failure scenario to see detection in action.</li>';
}
function renderEvents(list) {
  $("events").innerHTML = list.map((e) => `<li class="${e.level}"><div>${esc(e.message)}</div><div class="t">tick ${e.tick} | ${esc(e.category)}</div></li>`).join("");
}
function renderFailovers(list) {
  $("foTable").querySelector("tbody").innerHTML = list.length ? list.map((f) => `<tr><td>${f.tick}</td><td>${esc(f.from_server || "none")}</td><td>${esc(f.to_server)}</td>
    <td>${esc(f.trigger)}</td><td>${fmt(f.switch_ms, 0, " ms")}</td><td>${f.trigger === "failback" ? "planned" : fmt(f.ttr_s, 2, " s")}</td></tr>`).join("")
    : '<tr><td colspan="6">No failovers yet</td></tr>';
}
function renderStats(a) {
  const s = (v, l) => `<div class="stat"><b>${v}</b><span>${l}</span></div>`;
  $("stats").innerHTML = s(a.failovers_total, "Failovers") + s(fmt(a.failover_success_rate_pct, 0, "%"), "Failover success") +
    s(fmt(a.mttd_s, 1, " s"), "Mean time to detect") + s(fmt(a.mttr_s, 2, " s"), "Mean time to restore") +
    s(a.server_recoveries, "Server recoveries") + s(fmt(a.service_availability_pct, 1, "%"), "Service availability") +
    s(a.decisions_total, "Decisions made") + s(fmt(a.avg_decision_ms, 2, " ms"), "Avg decision time");
}

/* ---------- charts (plain canvas, no libraries) ---------- */
function drawChart(cv, xs, series, opt) {
  const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
  cv.width = W * dpr; cv.height = H * dpr;
  const g = cv.getContext("2d"); g.scale(dpr, dpr); g.clearRect(0, 0, W, H);
  const L = 38, R = 8, T = 8, B = 20, pw = W - L - R, ph = H - T - B;
  let max = opt.max || 1;
  series.forEach((s) => s.data.forEach((v) => { if (v != null && v > max) max = v; }));
  if (!opt.max) max = Math.ceil(max * 1.1);
  g.font = "11px sans-serif"; g.fillStyle = "#8ea1b3"; g.strokeStyle = "#28384a";
  for (let i = 0; i <= 4; i++) {
    const y = T + ph - (ph * i) / 4; g.beginPath(); g.moveTo(L, y); g.lineTo(W - R, y); g.stroke();
    g.fillText(Math.round((max * i) / 4), 2, y + 4);
  }
  const n = xs.length;
  if (!n) { g.fillText("no data yet", L + 10, T + 20); return; }
  const X = (i) => L + (opt.bars ? (pw * (i + 0.5)) / n : n > 1 ? (pw * i) / (n - 1) : pw / 2);
  const Y = (v) => T + ph - (ph * v) / max;
  if (opt.bars) {
    const bw = Math.max(4, Math.min(30, pw / n - 4));
    series[0].data.forEach((v, i) => { g.fillStyle = series[0].colors ? series[0].colors[i] : "#3b9eff"; g.fillRect(X(i) - bw / 2, Y(v), bw, T + ph - Y(v)); });
  } else {
    series.forEach((s) => {
      g.strokeStyle = s.color; g.lineWidth = 2; g.beginPath(); let pen = false;
      s.data.forEach((v, i) => { if (v == null) { pen = false; return; } pen ? g.lineTo(X(i), Y(v)) : g.moveTo(X(i), Y(v)); pen = true; });
      g.stroke();
      s.data.forEach((v, i) => { if (v == null) { g.fillStyle = "#e5484d"; g.fillRect(X(i) - 1.5, T + ph - 5, 3, 5); } });
    });
    let lx = L; series.forEach((s) => { g.fillStyle = s.color; g.fillRect(lx, H - 12, 10, 3); g.fillStyle = "#8ea1b3"; g.fillText(s.name, lx + 14, H - 6); lx += 80; });
  }
  g.fillStyle = "#8ea1b3"; g.fillText(opt.xl || "tick " + xs[0], L, H - 7 + (opt.bars ? 0 : -10) + 10 * 0);
}
function renderCharts(m, failovers) {
  const names = Object.keys(m.series);
  drawChart($("chLat"), m.ticks, names.map((k) => ({name: "Server " + k, color: COLORS[k], data: m.series[k].latency})), {max: 100});
  drawChart($("chLoad"), m.ticks, names.map((k) => ({name: "Server " + k, color: COLORS[k], data: m.series[k].load})), {max: 100});
  const fo = failovers.filter((f) => f.trigger !== "failback").slice(0, 12).reverse();
  drawChart($("chTtr"), fo.map((f) => f.tick), [{data: fo.map((f) => f.ttr_s), colors: fo.map((f) => COLORS[f.to_server] || "#3b9eff")}], {bars: true, xl: "failovers (oldest to newest), colour = target server"});
}

/* ---------- refresh loop ---------- */
let busy = false;
async function refresh() {
  if (busy) return; busy = true;
  try {
    const [st, dec, fo, an, mt, al, ev] = await Promise.all([
      api("/api/status"), api("/api/decisions/latest"), api("/api/failovers?limit=50"), api("/api/analytics"),
      api("/api/metrics?ticks=60"), api("/api/events?level=warning,critical&limit=8"), api("/api/events?limit=25")]);
    renderStatus(st); if (Date.now() > holdDecisionUntil) renderDecision(dec.decision); renderFailovers(fo.failovers); renderStats(an);
    renderCharts(mt, fo.failovers); renderAlerts(al.events); renderEvents(ev.events);
    $("conn").textContent = "connected"; $("conn").className = "conn on";
  } catch (e) { $("conn").textContent = "backend offline"; $("conn").className = "conn off"; }
  busy = false;
}

async function init() {
  const sc = await api("/api/scenarios");
  $("scenarios").innerHTML = sc.scenarios.map((s) => `<button class="sc" data-id="${s.id}" title="${esc(s.description)}">${esc(s.title)}</button>`).join("");
  $("scenarios").querySelectorAll("button").forEach((b) => b.addEventListener("click", () =>
    act(() => api("/api/scenarios/run", "POST", {scenario: b.dataset.id}), "Scenario started: " + b.textContent)));
  const opts = (arr, f) => arr.map((x) => `<option value="${x}">${f ? f(x) : x}</option>`).join("");
  $("injServer").innerHTML = opts(sc.servers, (x) => "Server " + x);
  $("injFault").innerHTML = opts(Object.keys(sc.fault_types));
  $("recoverBtns").innerHTML = sc.servers.map((x) => `<button data-s="${x}">Recover ${x}</button>`).join("");
  $("recoverBtns").querySelectorAll("button").forEach((b) => b.addEventListener("click", () =>
    act(() => api("/api/servers/" + b.dataset.s + "/recover", "POST", {}), "Recovery requested for " + b.dataset.s)));
  $("btnInject").onclick = () => act(() => api("/api/inject", "POST", {server: $("injServer").value, fault: $("injFault").value, ttl: parseInt($("injTtl").value, 10) || null}), "Fault injected (simulated)");
  $("btnTick").onclick = () => act(() => api("/api/tick", "POST", {n: 1}));
  $("btnTick5").onclick = () => act(() => api("/api/tick", "POST", {n: 5}));
  $("autorun").onchange = (e) => act(() => api("/api/autorun", "POST", {enabled: e.target.checked}));
  $("btnReset").onclick = () => { if (confirm("Reset the simulation and clear all recorded data?")) act(() => api("/api/reset", "POST", {}), "Simulation reset"); };
  $("btnWhatIf").onclick = () => act(async () => {
    const r = await api("/api/evaluate", "POST", {}); holdDecisionUntil = Date.now() + 20000;
    renderDecision({id: "what-if", tick: "now", trigger: "manual evaluation", outcome: "what_if", selected: r.selected, summary: "What-if (nothing executed): " + r.explanation, ranking: r.ranking, decision_ms: r.decision_ms});
  });
  $("btnWeights").onclick = () => {
    const w = {}; $("weights").querySelectorAll("input").forEach((i) => (w[i.dataset.k] = parseFloat(i.value)));
    weightsDirty = false; act(() => api("/api/weights", "PUT", {weights: w}), "Weights applied (normalised to sum 1)");
  };
  await refresh();
  setInterval(refresh, 1500);
}
init().catch((e) => { $("conn").textContent = "backend offline"; $("conn").className = "conn off"; toast("Cannot reach backend: " + e.message); setTimeout(() => location.reload(), 4000); });
window.addEventListener("resize", () => refresh());
