"""Framework-independent API (shared file).

All endpoints live here as plain functions, so the SAME API is served by
FastAPI (backend/main.py) and by the zero-dependency stdlib server
(backend/server_stdlib.py).
"""
import re

from . import decision_engine
from .simulation import FAULT_TYPES, SCENARIOS


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


def _int(q, key, default, lo=1, hi=1000):
    try:
        v = int(q.get(key, default))
    except (TypeError, ValueError):
        raise ApiError(400, "query parameter '%s' must be an integer" % key)
    return max(lo, min(hi, v))


def _body(body):
    if body is None:
        return {}
    if not isinstance(body, dict):
        raise ApiError(400, "JSON body must be an object")
    return body


class Router:
    def __init__(self, snd):
        self.snd = snd
        self.routes = []
        s = snd

        def add(method, pattern, fn):
            self.routes.append((method, re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", pattern) + "$"), fn))

        add("GET", "/api/health", lambda p, q, b: {"ok": True, "service": "SND", "simulation": True})
        add("GET", "/api/status", lambda p, q, b: s.status())
        add("GET", "/api/scenarios", lambda p, q, b: {
            "scenarios": [{"id": k, "title": v["title"], "description": v["description"]} for k, v in SCENARIOS.items()],
            "fault_types": FAULT_TYPES, "servers": s.ids})

        def tick(p, q, b):
            n = _body(b).get("n", 1)
            if not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= 100:
                raise ApiError(400, "'n' must be an integer 1..100")
            return {"ticks": [{"tick": r["tick"], "active": r["active"]} for r in s.advance(n)], "status": s.status()}
        add("POST", "/api/tick", tick)

        def autorun(p, q, b):
            en = _body(b).get("enabled")
            if not isinstance(en, bool):
                raise ApiError(400, "'enabled' must be true or false")
            s.autorun_enabled = en
            return {"autorun": en}
        add("POST", "/api/autorun", autorun)

        def run_sc(p, q, b):
            name = _body(b).get("scenario")
            try:
                return s.run_scenario(name)
            except KeyError:
                raise ApiError(404, "unknown scenario '%s'" % name)
        add("POST", "/api/scenarios/run", run_sc)

        def inject(p, q, b):
            b = _body(b)
            ttl = b.get("ttl")
            if ttl is not None and (not isinstance(ttl, int) or isinstance(ttl, bool) or not 1 <= ttl <= 500):
                raise ApiError(400, "'ttl' must be an integer 1..500 or omitted")
            try:
                s.inject(b.get("server"), b.get("fault"), ttl)
            except ValueError as e:
                raise ApiError(400, str(e))
            return {"injected": True, "server": b["server"], "fault": b["fault"], "ttl": ttl}
        add("POST", "/api/inject", inject)

        def recover(p, q, b):
            try:
                return {"server": p["sid"], "fault_cleared": s.recover_server(p["sid"])}
            except ValueError as e:
                raise ApiError(404, str(e))
        add("POST", "/api/servers/{sid}/recover", recover)
        add("POST", "/api/reset", lambda p, q, b: (s.reset(), {"reset": True})[1])
        add("GET", "/api/events", lambda p, q, b: {"events": s.db.events(
            _int(q, "limit", 50), [x for x in q.get("level", "").split(",") if x] or None, q.get("category"))})
        add("GET", "/api/decisions", lambda p, q, b: {"decisions": s.db.decisions(_int(q, "limit", 20))})

        def latest(p, q, b):
            d = s.db.decisions(1)
            return {"decision": d[0] if d else None}
        add("GET", "/api/decisions/latest", latest)
        add("GET", "/api/failovers", lambda p, q, b: {"failovers": s.db.failovers(_int(q, "limit", 50))})
        add("GET", "/api/recoveries", lambda p, q, b: {"recoveries": s.db.recoveries(_int(q, "limit", 50))})
        add("GET", "/api/analytics", lambda p, q, b: s.analytics())
        add("GET", "/api/metrics", lambda p, q, b: s.metrics_series(_int(q, "ticks", 60, 1, 500)))
        add("GET", "/api/weights", lambda p, q, b: {"weights": s.weights, "criteria": list(decision_engine.CRITERIA)})

        def put_w(p, q, b):
            try:
                return {"weights": s.set_weights(_body(b).get("weights"))}
            except ValueError as e:
                raise ApiError(400, str(e))
        add("PUT", "/api/weights", put_w)
        add("POST", "/api/evaluate", lambda p, q, b: s.what_if())

    def dispatch(self, method, path, query=None, body=None):
        """Returns (status_code, json_object)."""
        query = query or {}
        path = path.rstrip("/") or "/"
        known = False
        for m, rx, fn in self.routes:
            match = rx.match(path)
            if not match:
                continue
            known = True
            if m != method:
                continue
            try:
                result = fn(match.groupdict(), query, body)
                return 200, result
            except ApiError as e:
                return e.status, {"error": e.message}
            except Exception as e:  # never leak a traceback to the client
                return 500, {"error": "internal error: %s" % type(e).__name__}
        return (405, {"error": "method not allowed"}) if known else (404, {"error": "not found"})
