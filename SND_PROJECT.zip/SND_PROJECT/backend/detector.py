"""Infrastructure monitoring + failure detection (shared file).

Consumes health probes each tick and maintains a status per server:
healthy / degraded / failed, using consecutive-check thresholds so a single
blip does not trigger a failover.
"""
from collections import deque

from . import config


def classify(probe):
    if not probe["up"] or probe["latency_ms"] is None or probe["latency_ms"] > config.HEALTH_TIMEOUT_MS:
        return "fail"
    if probe["latency_ms"] > config.LATENCY_DEGRADED_MS or probe["load_pct"] > config.LOAD_DEGRADED_PCT:
        return "degraded"
    return "ok"


class ServerHealth:
    def __init__(self, sid):
        self.id = sid
        self.status = "healthy"
        self.fail = self.deg = self.ok = self.up_streak = 0
        self.history = deque(maxlen=20)
        self.since_tick = 0

    @property
    def recent_uptime(self):
        return sum(self.history) / len(self.history) if self.history else 1.0


class FailureDetector:
    def __init__(self, ids):
        self.health = {i: ServerHealth(i) for i in ids}

    def reset(self):
        self.health = {i: ServerHealth(i) for i in self.health}

    def observe(self, tick, probes):
        """Returns a list of transitions: {server, kind, from, to, count?, probe}."""
        out = []
        for sid, probe in probes.items():
            h = self.health[sid]
            cls = classify(probe)
            h.history.append(cls != "fail")
            if cls == "fail":
                h.fail, h.deg, h.ok, h.up_streak = h.fail + 1, 0, 0, 0
            elif cls == "degraded":
                h.fail, h.deg, h.ok, h.up_streak = 0, h.deg + 1, 0, h.up_streak + 1
            else:
                h.fail, h.deg, h.ok, h.up_streak = 0, 0, h.ok + 1, h.up_streak + 1
            old, new = h.status, h.status
            if h.fail >= config.FAIL_THRESHOLD:
                new = "failed"
            elif old == "failed":
                if h.up_streak >= config.RECOVER_THRESHOLD:
                    new = "healthy" if cls == "ok" else "degraded"
            elif old == "degraded":
                if h.ok >= config.RECOVER_THRESHOLD:
                    new = "healthy"
            elif h.deg >= config.DEGRADE_THRESHOLD:
                new = "degraded"
            if cls == "fail" and new != "failed" and h.fail >= 1:
                out.append({"server": sid, "kind": "suspect", "count": h.fail, "probe": probe})
            if cls == "degraded" and new == "healthy" and old == "healthy" and h.deg >= 1:
                out.append({"server": sid, "kind": "suspect_slow", "count": h.deg, "probe": probe})
            if new != old:
                h.status, h.since_tick = new, tick
                out.append({"server": sid, "kind": "transition", "from": old, "to": new, "probe": probe})
        return out
