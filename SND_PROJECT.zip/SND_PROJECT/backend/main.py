"""FastAPI application (shared file). Thin adapter over backend/api.py.

NOTE: written without being able to run FastAPI in the authoring sandbox
(offline). Verify on your machine with:  python run.py   then open /api/health
"""
import json
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from . import config
from .api import Router
from .snd_core import SND


def create_app(snd=None, autorun=True):
    snd = snd or SND()
    router = Router(snd)

    @asynccontextmanager
    async def lifespan(app):
        if autorun:
            snd.start_background()
        yield
        snd.stop_background()

    app = FastAPI(title="SND - Saudi Natural Digital (simulation prototype)", lifespan=lifespan)

    @app.api_route("/api/{path:path}", methods=["GET", "POST", "PUT"])
    async def api(path: str, request: Request):
        body = None
        if request.method in ("POST", "PUT"):
            raw = await request.body()
            if raw:
                try:
                    body = json.loads(raw)
                except ValueError:
                    return JSONResponse({"error": "invalid JSON body"}, status_code=400)
        status, obj = await run_in_threadpool(
            router.dispatch, request.method, "/api/" + path, dict(request.query_params), body)
        return JSONResponse(obj, status_code=status)

    app.mount("/", StaticFiles(directory=config.FRONTEND_DIR, html=True), name="frontend")
    return app
