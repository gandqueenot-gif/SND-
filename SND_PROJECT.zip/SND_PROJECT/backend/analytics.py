"""Performance analytics computed from the SQLite records (shared file)."""


def _avg(x):
    return round(sum(x) / len(x), 3) if x else None


def compute(db):
    fo = [f for f in db.failovers(1000) if f["trigger"] != "failback"]
    ttd = [f["ttd_s"] for f in fo if f["ttd_s"] is not None]
    ttr = [f["ttr_s"] for f in fo if f["ttr_s"] is not None]
    rec = db.recoveries(1000)
    total_ticks = db.scalar("SELECT COUNT(*) FROM ticks") or 0
    up_ticks = db.scalar("SELECT COALESCE(SUM(service_up),0) FROM ticks") or 0
    dec = db.decisions(1000)
    per_server = {}
    for r in db._all("SELECT server, COUNT(*) AS n, SUM(up) AS up, "
                     "AVG(CASE WHEN up=1 THEN latency_ms END) AS lat, AVG(load_pct) AS load "
                     "FROM metrics GROUP BY server ORDER BY server"):
        per_server[r["server"]] = {
            "samples": r["n"],
            "uptime_pct": round(100.0 * (r["up"] or 0) / r["n"], 2) if r["n"] else None,
            "avg_latency_ms": round(r["lat"], 1) if r["lat"] is not None else None,
            "avg_load_pct": round(r["load"], 1) if r["load"] is not None else None}
    by_trigger = {}
    for f in db.failovers(1000):
        by_trigger[f["trigger"]] = by_trigger.get(f["trigger"], 0) + 1
    return {
        "ticks_observed": total_ticks,
        "service_availability_pct": round(100.0 * up_ticks / total_ticks, 2) if total_ticks else None,
        "failovers_total": len(fo) + by_trigger.get("failback", 0),
        "failovers_by_trigger": by_trigger,
        "failover_success_rate_pct": round(100.0 * sum(f["success"] for f in fo) / len(fo), 1) if fo else None,
        "mttd_s": _avg(ttd),
        "mttr_s": _avg(ttr),
        "mttr_min_s": min(ttr) if ttr else None,
        "mttr_max_s": max(ttr) if ttr else None,
        "server_recoveries": len(rec),
        "avg_server_downtime_s": _avg([r["downtime_s"] for r in rec]),
        "decisions_total": len(dec),
        "avg_decision_ms": _avg([d["decision_ms"] for d in dec]),
        "events_by_level": {r["level"]: r["n"] for r in db._all(
            "SELECT level, COUNT(*) AS n FROM events GROUP BY level")},
        "per_server": per_server,
        "note": "All figures come from the local simulation (1 tick = 1 simulated second).",
    }
