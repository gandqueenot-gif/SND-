"""Weighted multi-criteria decision engine (owner: Ghand).

Pure functions: no database, no I/O. Scores every candidate service on five
criteria (each 0..1, higher is better) and combines them with weights.
"""
from . import config

CRITERIA = ("latency", "load", "reliability", "cost", "health")


def _clip(x):
    return max(0.0, min(1.0, x))


def normalize_weights(weights):
    """Validate and normalise weights so they sum to 1. Raises ValueError."""
    if not isinstance(weights, dict):
        raise ValueError("weights must be an object")
    missing = [c for c in CRITERIA if c not in weights]
    if missing:
        raise ValueError("missing weights: " + ", ".join(missing))
    out = {}
    for c in CRITERIA:
        try:
            v = float(weights[c])
        except (TypeError, ValueError):
            raise ValueError("weight '%s' must be a number" % c)
        if v < 0 or v != v:
            raise ValueError("weight '%s' must be >= 0" % c)
        out[c] = v
    total = sum(out.values())
    if total <= 0:
        raise ValueError("at least one weight must be > 0")
    return {c: round(v / total, 6) for c, v in out.items()}


def criteria_scores(c):
    uptime = c.get("recent_uptime", 1.0)
    return {
        "latency": _clip(1 - (c["latency_ms"] or 0) / config.LATENCY_CEILING_MS),
        "load": _clip(1 - c["load_pct"] / 100.0),
        "reliability": _clip(0.5 * _clip((c["reliability"] - 0.90) / 0.10) + 0.5 * uptime),
        "cost": _clip(1 - c["cost"] / config.MAX_COST),
        "health": 1.0 if c["status"] == "healthy" else 0.4,
    }


def _ineligible_reason(c):
    if c["status"] == "failed":
        return "failed health checks"
    if c["status"] not in ("healthy", "degraded"):
        return "unknown status"
    if c.get("latency_ms") is None:
        return "no response"
    return None


def evaluate(candidates, weights=None, current=None, min_score=None):
    """Rank candidates. `current` (id of the active service) is scored but never selected.

    candidate keys: id, name, status, latency_ms, load_pct, reliability, recent_uptime, cost
    """
    w = normalize_weights(weights or config.DEFAULT_WEIGHTS)
    min_score = config.MIN_VIABLE_SCORE if min_score is None else min_score
    ranking = []
    for c in candidates:
        reason = _ineligible_reason(c)
        entry = {"server": c["id"], "name": c.get("name", c["id"]), "status": c["status"],
                 "eligible": reason is None, "is_current": c["id"] == current,
                 "score": 0.0, "criteria": {}, "reason": reason or "available"}
        if reason is None:
            cs = criteria_scores(c)
            raw = {"latency": c["latency_ms"], "load": c["load_pct"],
                   "reliability": c["reliability"], "cost": c["cost"], "health": c["status"]}
            for k in CRITERIA:
                entry["criteria"][k] = {"raw": raw[k], "score": round(cs[k], 4),
                                        "weight": w[k], "contribution": round(cs[k] * w[k], 4)}
            entry["score"] = round(sum(v["contribution"] for v in entry["criteria"].values()), 4)
        ranking.append(entry)
    ranking.sort(key=lambda e: (-e["score"], e["server"]))
    for i, e in enumerate(ranking, 1):
        e["rank"] = i
    options = [e for e in ranking if e["eligible"] and not e["is_current"]]
    best = options[0] if options else None
    if best is not None and best["score"] < min_score:
        best = None
    if best:
        others = [e for e in options if e is not best]
        if others:
            explanation = "%s selected with score %.3f; next best alternative %s scored %.3f." % (
                best["name"], best["score"], others[0]["name"], others[0]["score"])
        else:
            explanation = "%s selected with score %.3f (only available alternative)." % (
                best["name"], best["score"])
    else:
        explanation = "No viable alternative: every candidate is unavailable, current, or below the minimum score."
    return {"weights": w, "ranking": ranking, "selected": best["server"] if best else None,
            "explanation": explanation}
