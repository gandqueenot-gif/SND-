"""SND configuration. All values are for the LOCAL SIMULATION only."""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
DB_PATH = os.environ.get("SND_DB_PATH", os.path.join(BASE_DIR, "data", "snd.db"))

TICK_SECONDS = 1.0          # 1 tick = 1 simulated second of infrastructure time
AUTORUN_INTERVAL = 1.5      # real seconds between automatic ticks

# --- failure detection ---
FAIL_THRESHOLD = 2          # consecutive failed health checks -> "failed"
DEGRADE_THRESHOLD = 2       # consecutive slow/overloaded checks -> "degraded"
RECOVER_THRESHOLD = 2       # consecutive good checks -> back to "healthy"
LATENCY_DEGRADED_MS = 250.0
LOAD_DEGRADED_PCT = 90.0
HEALTH_TIMEOUT_MS = 1000.0

# --- decision engine ---
DEFAULT_WEIGHTS = {"latency": 0.30, "load": 0.20, "reliability": 0.20,
                   "cost": 0.10, "health": 0.20}
LATENCY_CEILING_MS = 500.0
MAX_COST = 1.5
MIN_VIABLE_SCORE = 0.30
TRAFFIC_LOAD_PCT = 15.0     # extra load a server takes when it carries the traffic

# --- recovery management ---
FAILBACK_COOLDOWN_TICKS = 5
FAILBACK_TOLERANCE = 0.05   # return to preferred primary if its score >= active - tolerance
