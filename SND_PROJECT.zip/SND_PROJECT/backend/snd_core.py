"""SND orchestrator (shared file): monitor -> detect -> decide -> failover -> recover -> log."""
import threading
import time

from . import analytics, config, decision_engine
from .database import Database
from .detector import FailureDetector
from .simulation import FAULT_TYPES, PREFERRED_PRIMARY, SCENARIOS, Infrastructure


class SND:
    def __init__(self, db_path=None, seed=None):
        self.lock = threading.RLock()
        self.db = Database(db_path or config.DB_PATH)
        self.sim = Infrastructure(seed)
        self.ids = self.sim.ids
        self.det = FailureDetector(self.ids)
        self.autorun_enabled = False
        self._bg = None
        self._stop = threading.Event()
        self.last_probes = {}
        self.incidents = {}      # server -> {"start","detect"} for the current fault
        self.outage = None       # set while no service is active
        self.cooldown_until = 0
        self._last_key = None    # de-duplicates repeated non-action decisions
        self.tick_no = self.db.get_state("tick", 0)
        self.active = self.db.get_state("active", PREFERRED_PRIMARY)
        self.weights = decision_engine.normalize_weights(
            self.db.get_state("weights", config.DEFAULT_WEIGHTS))
        self.sim.active_id = self.active
        if self.tick_no == 0:
            self._log("info", "system", "SND started (local simulation, no real infrastructure).")

    # ------------------------------------------------------------ helpers
    def _log(self, level, category, message, server=None, **details):
        return self.db.add_event(self.tick_no, level, category, server, message, details)

    def _name(self, sid):
        return next(s.profile["name"] for s in self.sim.servers.values() if s.profile["id"] == sid) if sid else "none"

    def _candidate(self, sid):
        p = self.sim.servers[sid].profile
        probe = self.last_probes.get(sid) or {"up": True, "latency_ms": p["base_latency"],
                                              "load_pct": p["base_load"]}
        h = self.det.health[sid]
        load = probe["load_pct"]
        if sid != self.active and probe["up"]:   # projected load if traffic moved here
            load = min(100.0, load + config.TRAFFIC_LOAD_PCT)
        return {"id": sid, "name": p["name"], "status": h.status, "latency_ms": probe["latency_ms"],
                "load_pct": load, "reliability": p["reliability"], "cost": p["cost"],
                "recent_uptime": h.recent_uptime}

    def _evaluate(self, trigger=None):
        t0 = time.perf_counter()
        res = decision_engine.evaluate([self._candidate(s) for s in self.ids], self.weights,
                                       current=self.active)
        res["decision_ms"] = round((time.perf_counter() - t0) * 1000, 3)
        return res

    # ------------------------------------------------------------ tick
    def tick(self):
        with self.lock:
            self.tick_no += 1
            t = self.tick_no
            self.sim.active_id = self.active
            probes = self.sim.step(t)
            self.last_probes = probes
            for sid, msg in self.sim.events:
                self._log("info", "simulation", msg, sid)
            transitions = self.det.observe(t, probes)
            for sid, p in probes.items():
                self.db.add_metric(t, sid, p["latency_ms"], p["load_pct"], p["up"], self.det.health[sid].status)
            self._handle_transitions(t, transitions)
            decision = self._decide(t)
            service_up = self.active is not None and probes[self.active]["up"]
            self.db.add_tick(t, self.active, service_up)
            self.db.set_state("tick", t)
            self.db.set_state("active", self.active)
            return {"tick": t, "active": self.active, "decision": decision,
                    "transitions": [x for x in transitions if x["kind"] == "transition"]}

    def advance(self, n):
        return [self.tick() for _ in range(n)]

    def _handle_transitions(self, t, transitions):
        for tr in transitions:
            sid, nm = tr["server"], self._name(tr["server"])
            if tr["kind"] == "suspect":
                self._log("warning", "detection", "%s missed a health check (%d/%d) - verifying"
                          % (nm, tr["count"], config.FAIL_THRESHOLD), sid)
            elif tr["kind"] == "suspect_slow":
                self._log("info", "detection", "%s responding slowly or under heavy load (%d/%d)"
                          % (nm, tr["count"], config.DEGRADE_THRESHOLD), sid)
            elif tr["to"] in ("failed", "degraded") and tr["from"] == "healthy" or \
                    (tr["to"] == "failed"):
                info = self.sim.fault_info(sid)
                start = info[1] if info else t
                self.incidents[sid] = {"start": start, "detect": t, "fault": info[0] if info else "unknown"}
                lvl = "critical" if tr["to"] == "failed" else "warning"
                self._log(lvl, "detection", "FAILURE DETECTED: %s is now %s (fault began tick %d, detected tick %d)"
                          % (nm, tr["to"].upper(), start, t), sid, fault=self.incidents[sid]["fault"])
            elif tr["from"] == "failed" and tr["to"] == "degraded":
                self._log("info", "recovery", "%s is responding again but still degraded" % nm, sid)
            elif tr["to"] == "healthy":
                inc = self.incidents.pop(sid, None)
                if inc:
                    down = (t - inc["start"]) * config.TICK_SECONDS
                    self.db.add_recovery(t, sid, inc["fault"], inc["start"], t, down)
                    self._log("info", "recovery", "RECOVERED: %s is healthy again after %.0f s (simulated). "
                              "Returned to standby pool." % (nm, down), sid, downtime_s=down)
                else:
                    self._log("info", "recovery", "%s is healthy" % nm, sid)

    # ------------------------------------------------------------ decisions
    def _decide(self, t):
        a = self.active
        if a is None:
            return self._failover_decision(t, "outage_restore")
        st = self.det.health[a].status
        if st in ("failed", "degraded"):
            return self._failover_decision(t, "active_" + st)
        self._last_key = None
        return self._maybe_failback(t)

    def _record_decision(self, t, trigger, res, outcome, summary):
        return self.db.add_decision(t, trigger, self.active, res["selected"], outcome, summary,
                                    res["ranking"], res["weights"], res["decision_ms"])

    def _failover_decision(self, t, trigger):
        res = self._evaluate(trigger)
        sel = res["selected"]
        cur = next((e for e in res["ranking"] if e["server"] == self.active), None)
        if sel is None:
            outcome = "no_alternative"
        elif trigger == "active_degraded" and cur and cur["eligible"] and \
                next(e for e in res["ranking"] if e["server"] == sel)["score"] <= cur["score"]:
            outcome = "retained"
        else:
            outcome = "failover"
        key = (outcome, sel)
        if outcome != "failover":
            if key == self._last_key:
                return None
            self._last_key = key
        else:
            self._last_key = None
        if outcome == "no_alternative":
            summary = res["explanation"]
            did = self._record_decision(t, trigger, res, outcome, summary)
            if self.active is not None:
                inc = self.incidents.get(self.active, {"start": t, "detect": t})
                self.outage = {"start": inc["start"], "detect": inc["detect"]}
                self._log("critical", "decision", "SERVICE OUTAGE: no viable alternative. " + summary,
                          self.active, decision_id=did)
                self.active = None
                self.sim.active_id = None
            return {"id": did, "outcome": outcome}
        if outcome == "retained":
            summary = "Active server is degraded but no alternative scores higher; retaining %s." % self._name(self.active)
            did = self._record_decision(t, trigger, res, outcome, summary)
            self._log("info", "decision", summary, self.active, decision_id=did)
            return {"id": did, "outcome": outcome}
        summary = res["explanation"]
        did = self._record_decision(t, trigger, res, outcome, summary)
        self._log("info", "decision", "DECISION: " + summary, sel, decision_id=did)
        self._execute_failover(t, trigger, sel, did)
        return {"id": did, "outcome": outcome, "selected": sel}

    def _maybe_failback(self, t):
        pref = PREFERRED_PRIMARY
        if self.active == pref or t < self.cooldown_until or self.det.health[pref].status != "healthy":
            return None
        res = self._evaluate("failback")
        pe = next(e for e in res["ranking"] if e["server"] == pref)
        ae = next(e for e in res["ranking"] if e["server"] == self.active)
        if not pe["eligible"] or pe["score"] < ae["score"] - config.FAILBACK_TOLERANCE:
            return None
        summary = ("Preferred primary %s recovered (score %.3f vs %.3f on %s): planned failback."
                   % (pe["name"], pe["score"], ae["score"], ae["name"]))
        res["selected"] = pref
        did = self._record_decision(t, "failback", res, "failover", summary)
        self._log("info", "decision", "DECISION: " + summary, pref, decision_id=did)
        self._execute_failover(t, "failback", pref, did)
        return {"id": did, "outcome": "failover", "selected": pref}

    def _execute_failover(self, t, trigger, to_id, decision_id):
        frm = self.active
        target = self._candidate(to_id)
        switch_ms = round(150 + 4 * (target["latency_ms"] or 0) + 2 * target["load_pct"], 1)
        if trigger == "failback":
            start = detect = t
        elif frm is None and self.outage:
            start, detect = self.outage["start"], self.outage["detect"]
        else:
            inc = self.incidents.get(frm, {"start": t, "detect": t})
            start, detect = inc["start"], inc["detect"]
        ttd = (detect - start) * config.TICK_SECONDS
        ttr = (t - start) * config.TICK_SECONDS + switch_ms / 1000.0
        success = bool(self.last_probes.get(to_id, {}).get("up"))
        self.db.add_failover(t, frm, to_id, trigger, decision_id, switch_ms, success,
                             start, detect, t, ttd, round(ttr, 3))
        if success:
            self.active, self.outage = to_id, None
            self.sim.active_id = to_id
            self.cooldown_until = t + config.FAILBACK_COOLDOWN_TICKS
            if trigger == "failback":
                self._log("info", "failover", "PLANNED FAILBACK COMPLETE (simulated): %s -> %s in %.0f ms"
                          % (self._name(frm), self._name(to_id), switch_ms), to_id, decision_id=decision_id)
            else:
                self._log("info", "failover", "FAILOVER COMPLETE (simulated): %s -> %s in %.0f ms; service restored %.1f s after fault start"
                          % (self._name(frm), self._name(to_id), switch_ms, ttr), to_id, decision_id=decision_id)
        else:
            self._log("critical", "failover", "Failover to %s FAILED (target not responding)" % self._name(to_id), to_id)

    # ------------------------------------------------------------ control API
    def run_scenario(self, name):
        with self.lock:
            sc = SCENARIOS.get(name)
            if not sc:
                raise KeyError(name)
            for f in sc["faults"]:
                tgt = self.active if f["target"] == "active" else f["target"]
                if tgt is None:
                    tgt = PREFERRED_PRIMARY
                self.sim.inject(tgt, f["fault"], self.tick_no + 1 + f["delay"], f["ttl"])
            self._log("info", "scenario", "SCENARIO STARTED (simulated): %s" % sc["title"], None, scenario=name)
            return {"scenario": name, "title": sc["title"], "faults": len(sc["faults"])}

    def inject(self, sid, fault, ttl=None):
        with self.lock:
            self.sim.inject(sid, fault, self.tick_no + 1, ttl)
            self._log("info", "scenario", "MANUAL FAULT INJECTED (simulated): %s on %s%s"
                      % (fault, sid, " for %d ticks" % ttl if ttl else " until cleared"), sid)

    def recover_server(self, sid):
        with self.lock:
            had = self.sim.clear(sid)
            self._log("info", "scenario", "Manual recovery requested for %s (simulated fault cleared)" % sid, sid)
            return had

    def set_weights(self, w):
        with self.lock:
            self.weights = decision_engine.normalize_weights(w)
            self.db.set_state("weights", self.weights)
            self._log("info", "system", "Decision weights updated", None, weights=self.weights)
            return self.weights

    def what_if(self):
        with self.lock:
            return self._evaluate("what_if")

    def reset(self):
        with self.lock:
            self.db.reset()
            self.sim.reset()
            self.det.reset()
            self.tick_no, self.active, self.outage = 0, PREFERRED_PRIMARY, None
            self.incidents, self.last_probes, self._last_key, self.cooldown_until = {}, {}, None, 0
            self.weights = decision_engine.normalize_weights(config.DEFAULT_WEIGHTS)
            self._log("info", "system", "System reset. Simulation restarted.")

    def status(self):
        with self.lock:
            servers = []
            for sid in self.ids:
                s = self.sim.servers[sid]
                h = self.det.health[sid]
                p = self.last_probes.get(sid)
                servers.append({**{k: s.profile[k] for k in ("id", "name", "region", "reliability", "cost")},
                                "status": h.status, "is_active": sid == self.active,
                                "up": p["up"] if p else None,
                                "latency_ms": p["latency_ms"] if p else None,
                                "load_pct": p["load_pct"] if p else None,
                                "recent_uptime": round(h.recent_uptime, 3),
                                "since_tick": h.since_tick,
                                "injected_fault": s.fault})
            return {"tick": self.tick_no, "active": self.active,
                    "active_name": self._name(self.active) if self.active else None,
                    "service_state": "OUTAGE" if self.active is None else
                    ("DEGRADED" if self.det.health[self.active].status == "degraded" else "OPERATIONAL"),
                    "autorun": self.autorun_enabled, "weights": self.weights,
                    "servers": servers, "simulation": True,
                    "disclaimer": "All infrastructure is simulated locally. Nothing real is controlled."}

    def metrics_series(self, ticks=60):
        rows = self.db.recent_metrics(ticks)
        out = {"ticks": [], "series": {sid: {"latency": [], "load": [], "status": []} for sid in self.ids}}
        by_tick = {}
        for r in rows:
            by_tick.setdefault(r["tick"], {})[r["server"]] = r
        for t in sorted(by_tick):
            out["ticks"].append(t)
            for sid in self.ids:
                r = by_tick[t].get(sid)
                out["series"][sid]["latency"].append(r["latency_ms"] if r else None)
                out["series"][sid]["load"].append(r["load_pct"] if r and r["up"] else None)
                out["series"][sid]["status"].append(r["status"] if r else None)
        return out

    def analytics(self):
        with self.lock:
            return analytics.compute(self.db)

    # ------------------------------------------------------------ background
    def start_background(self, interval=None, autorun=True):
        interval = interval or config.AUTORUN_INTERVAL
        self.autorun_enabled = autorun
        if self._bg and self._bg.is_alive():
            return
        self._stop.clear()

        def loop():
            while not self._stop.wait(interval):
                if self.autorun_enabled:
                    try:
                        self.tick()
                    except Exception as exc:  # keep the simulator alive
                        print("tick error:", exc)
        self._bg = threading.Thread(target=loop, daemon=True)
        self._bg.start()

    def stop_background(self):
        self._stop.set()
