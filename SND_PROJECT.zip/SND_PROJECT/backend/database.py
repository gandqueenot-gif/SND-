"""SQLite persistence layer (owner: Ghand)."""
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, tick INTEGER, level TEXT,
  category TEXT, server TEXT, message TEXT, details TEXT);
CREATE TABLE IF NOT EXISTS decisions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, tick INTEGER, trigger TEXT,
  from_server TEXT, selected TEXT, outcome TEXT, summary TEXT,
  ranking TEXT, weights TEXT, decision_ms REAL);
CREATE TABLE IF NOT EXISTS failovers(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, tick INTEGER, from_server TEXT,
  to_server TEXT, trigger TEXT, decision_id INTEGER, switch_ms REAL, success INTEGER,
  fault_start_tick INTEGER, detect_tick INTEGER, restore_tick INTEGER,
  ttd_s REAL, ttr_s REAL);
CREATE TABLE IF NOT EXISTS recoveries(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, tick INTEGER, server TEXT, fault TEXT,
  fault_start_tick INTEGER, recovered_tick INTEGER, downtime_s REAL);
CREATE TABLE IF NOT EXISTS metrics(
  id INTEGER PRIMARY KEY AUTOINCREMENT, tick INTEGER, server TEXT,
  latency_ms REAL, load_pct REAL, up INTEGER, status TEXT);
CREATE INDEX IF NOT EXISTS idx_metrics_tick ON metrics(tick);
CREATE TABLE IF NOT EXISTS ticks(
  tick INTEGER PRIMARY KEY, ts TEXT, active TEXT, service_up INTEGER);
CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY, value TEXT);
"""
TABLES = ["events", "decisions", "failovers", "recoveries", "metrics", "ticks", "state"]
JSON_FIELDS = ("details", "ranking", "weights")


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    def __init__(self, path):
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.path = path
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        with self.lock:
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    def _exec(self, sql, args=()):
        with self.lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur

    def _all(self, sql, args=()):
        with self.lock:
            rows = [dict(r) for r in self.conn.execute(sql, args).fetchall()]
        for r in rows:
            for f in JSON_FIELDS:
                if f in r and isinstance(r[f], str):
                    try:
                        r[f] = json.loads(r[f])
                    except ValueError:
                        pass
        return rows

    def close(self):
        with self.lock:
            self.conn.close()

    # ---- writes ----
    def add_event(self, tick, level, category, server, message, details=None):
        return self._exec(
            "INSERT INTO events(ts,tick,level,category,server,message,details) VALUES(?,?,?,?,?,?,?)",
            (now_iso(), tick, level, category, server, message, json.dumps(details or {}))).lastrowid

    def add_decision(self, tick, trigger, from_server, selected, outcome, summary,
                     ranking, weights, decision_ms):
        return self._exec(
            "INSERT INTO decisions(ts,tick,trigger,from_server,selected,outcome,summary,ranking,weights,decision_ms)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (now_iso(), tick, trigger, from_server, selected, outcome, summary,
             json.dumps(ranking), json.dumps(weights), decision_ms)).lastrowid

    def add_failover(self, tick, from_server, to_server, trigger, decision_id, switch_ms,
                     success, fault_start, detect, restore, ttd_s, ttr_s):
        return self._exec(
            "INSERT INTO failovers(ts,tick,from_server,to_server,trigger,decision_id,switch_ms,success,"
            "fault_start_tick,detect_tick,restore_tick,ttd_s,ttr_s) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (now_iso(), tick, from_server, to_server, trigger, decision_id, switch_ms,
             1 if success else 0, fault_start, detect, restore, ttd_s, ttr_s)).lastrowid

    def add_recovery(self, tick, server, fault, fault_start, recovered, downtime_s):
        return self._exec(
            "INSERT INTO recoveries(ts,tick,server,fault,fault_start_tick,recovered_tick,downtime_s)"
            " VALUES(?,?,?,?,?,?,?)",
            (now_iso(), tick, server, fault, fault_start, recovered, downtime_s)).lastrowid

    def add_metric(self, tick, server, latency, load, up, status):
        self._exec("INSERT INTO metrics(tick,server,latency_ms,load_pct,up,status) VALUES(?,?,?,?,?,?)",
                   (tick, server, latency, load, 1 if up else 0, status))

    def add_tick(self, tick, active, service_up):
        self._exec("INSERT OR REPLACE INTO ticks(tick,ts,active,service_up) VALUES(?,?,?,?)",
                   (tick, now_iso(), active, 1 if service_up else 0))
        if tick % 200 == 0:  # keep the metrics table bounded
            self._exec("DELETE FROM metrics WHERE tick < ?", (tick - 2000,))

    def set_state(self, key, value):
        self._exec("INSERT OR REPLACE INTO state(key,value) VALUES(?,?)", (key, json.dumps(value)))

    def get_state(self, key, default=None):
        rows = self._all("SELECT value FROM state WHERE key=?", (key,))
        return json.loads(rows[0]["value"]) if rows else default

    def reset(self):
        for t in TABLES:
            self._exec("DELETE FROM %s" % t)

    # ---- reads ----
    @staticmethod
    def _lim(limit):
        return max(1, min(int(limit), 1000))

    def events(self, limit=50, levels=None, category=None):
        sql, args, where = "SELECT * FROM events", [], []
        if levels:
            where.append("level IN (%s)" % ",".join("?" * len(levels)))
            args += list(levels)
        if category:
            where.append("category=?")
            args.append(category)
        if where:
            sql += " WHERE " + " AND ".join(where)
        return self._all(sql + " ORDER BY id DESC LIMIT ?", args + [self._lim(limit)])

    def decisions(self, limit=20):
        return self._all("SELECT * FROM decisions ORDER BY id DESC LIMIT ?", (self._lim(limit),))

    def failovers(self, limit=50):
        return self._all("SELECT * FROM failovers ORDER BY id DESC LIMIT ?", (self._lim(limit),))

    def recoveries(self, limit=50):
        return self._all("SELECT * FROM recoveries ORDER BY id DESC LIMIT ?", (self._lim(limit),))

    def recent_metrics(self, ticks=60, server=None):
        row = self._all("SELECT MAX(tick) AS m FROM metrics")
        top = row[0]["m"] if row and row[0]["m"] is not None else 0
        sql, args = "SELECT * FROM metrics WHERE tick > ?", [top - self._lim(ticks)]
        if server:
            sql += " AND server=?"
            args.append(server)
        return self._all(sql + " ORDER BY tick ASC, server ASC", args)

    def scalar(self, sql, args=()):
        rows = self._all(sql, args)
        return list(rows[0].values())[0] if rows else None
