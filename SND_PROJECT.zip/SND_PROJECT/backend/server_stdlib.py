"""Zero-dependency server (shared file). Serves the same API + the dashboard.

Used as a fallback when FastAPI cannot be installed, and by the automated tests.
"""
import json
import mimetypes
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl, urlparse

from . import config
from .api import Router


def make_server(snd, host="127.0.0.1", port=8000):
    router = Router(snd)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, status, data, ctype="application/json"):
            raw = data if isinstance(data, bytes) else json.dumps(data).encode()
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(raw)

        def _api(self, method):
            u = urlparse(self.path)
            body = None
            if method in ("POST", "PUT"):
                n = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(n) if n else b""
                if raw:
                    try:
                        body = json.loads(raw)
                    except ValueError:
                        return self._send(400, {"error": "invalid JSON body"})
            status, obj = router.dispatch(method, u.path, dict(parse_qsl(u.query)), body)
            self._send(status, obj)

        def _static(self):
            path = urlparse(self.path).path
            rel = "index.html" if path in ("/", "") else path.lstrip("/")
            full = os.path.realpath(os.path.join(config.FRONTEND_DIR, rel))
            root = os.path.realpath(config.FRONTEND_DIR)
            if not full.startswith(root + os.sep) or not os.path.isfile(full):
                return self._send(404, {"error": "not found"})
            with open(full, "rb") as f:
                self._send(200, f.read(), mimetypes.guess_type(full)[0] or "application/octet-stream")

        def do_GET(self):
            self._api("GET") if self.path.startswith("/api/") else self._static()

        def do_POST(self):
            self._api("POST") if self.path.startswith("/api/") else self._send(404, {"error": "not found"})

        def do_PUT(self):
            self._api("PUT") if self.path.startswith("/api/") else self._send(404, {"error": "not found"})

    return ThreadingHTTPServer((host, port), Handler)
