# SND - Saudi Natural Digital (simulation prototype)

Intelligent failover prototype: monitors 3 **simulated** servers (A, B, C), detects failures,
scores alternatives with a weighted decision engine, fails over, manages recovery, logs everything
to SQLite and shows it on a live dashboard.

> **All infrastructure is simulated locally.** No real server, network or cloud resource is touched.
> Latency/load numbers come from a random model; "failover" means switching a variable in the simulator.

## بداية سريعة (iPad / Claude Code)
1. افتح الـ Terminal داخل مجلد المشروع.
2. `pip install -r requirements.txt`  (إذا فشل التثبيت تجاوزه واستخدم الخطوة 3-ب)
3. شغّل:
   - أ) `python run.py`  (FastAPI)
   - ب) `python run.py --stdlib`  (بدون أي تثبيت، نفس الـ API ونفس اللوحة)
4. افتح `http://localhost:8000` (أو رابط المنفذ 8000 الذي توفره بيئتك).
5. اضغط زر سيناريو مثل **Active server crash** وراقب: الكشف ← تقييم البدائل ← الاختيار ← التعافي.

## Quick start (English)
```
pip install -r requirements.txt     # optional
python run.py                       # FastAPI if installed, else built-in server automatically
python run.py --stdlib              # force dependency-free server
python run.py --host 0.0.0.0 --port 8000
```
Run tests: `python -m unittest discover -s tests -v` (no extra packages needed).

## Demo walkthrough
1. Dashboard shows A (ACTIVE), B, C all HEALTHY. Auto-run ticks every 1.5 s (toggle available).
2. Click **Active server crash**. A misses a health check (warning), then is declared FAILED (critical).
3. The **Decision engine** table shows each server's weighted score, per-criterion scores and the SELECTED one.
4. Failover history + event log record it; stats show time-to-detect / time-to-restore.
5. When the fault ends, A recovers and SND does a **planned failback** to the preferred primary.
6. Try **Total outage** (no alternative -> OUTAGE), **Degraded standby**, **Cascading failure**.
7. Change decision weights (e.g. cost only) and run again: a different server wins.

## Structure
```
run.py                    launcher
backend/  config.py database.py simulation.py decision_engine.py   (Ghand)
          detector.py snd_core.py analytics.py api.py main.py server_stdlib.py  (shared)
frontend/ index.html style.css app.js                              (Seba)
tests/    decision engine, detector, workflow, HTTP API
docs/     ARCHITECTURE.md TESTING.md COLLABORATION.md
data/     snd.db (created at runtime, git-ignored)
```

## Limitations (honest list)
- Simulation only; no real infrastructure integration.
- The FastAPI adapter (`backend/main.py`) was written offline and **not executed**; the identical API is tested through the stdlib server. Run `python run.py` and open `/api/health` to verify on your machine.
- Dependency pins in requirements.txt were not installed/verified offline.
- Injected faults are reset on restart (tick, active server, weights and history persist).
- No authentication: keep it on localhost.
