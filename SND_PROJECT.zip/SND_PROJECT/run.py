"""Start SND.   python run.py            (FastAPI if installed, else stdlib fallback)
                python run.py --stdlib   (force zero-dependency server)
                python run.py --host 0.0.0.0 --port 8000 --no-autorun
"""
import argparse
import sys

from backend.snd_core import SND

ap = argparse.ArgumentParser()
ap.add_argument("--host", default="127.0.0.1")
ap.add_argument("--port", type=int, default=8000)
ap.add_argument("--stdlib", action="store_true", help="use the built-in server (no pip install needed)")
ap.add_argument("--no-autorun", action="store_true", help="do not tick automatically")
a = ap.parse_args()

print("SND prototype - ALL INFRASTRUCTURE IS SIMULATED LOCALLY.")
use_fastapi = not a.stdlib
if use_fastapi:
    try:
        import fastapi, uvicorn  # noqa: F401
    except ImportError:
        print("FastAPI/uvicorn not installed -> using built-in stdlib server "
              "(same API). Run: pip install -r requirements.txt to use FastAPI.")
        use_fastapi = False

if use_fastapi:
    from backend.main import create_app
    print("Server: FastAPI + uvicorn | open http://%s:%d" % (a.host, a.port))
    uvicorn.run(create_app(autorun=not a.no_autorun), host=a.host, port=a.port, log_level="warning")
else:
    from backend.server_stdlib import make_server
    snd = SND()
    snd.start_background(autorun=not a.no_autorun)
    srv = make_server(snd, a.host, a.port)
    print("Server: stdlib | open http://%s:%d" % (a.host, a.port))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
