# Collaboration (Ghand & Seba)
No SND_MASTER_BLUEPRINT.md or earlier file split existed in the project, so this split is a *proposal*.
If you already agreed another six files, swap the names and keep the rules.

| Owner | Six owned files |
|---|---|
| Ghand (backend logic) | `backend/database.py`, `backend/simulation.py`, `backend/decision_engine.py` |
| Seba (dashboard) | `frontend/index.html`, `frontend/style.css`, `frontend/app.js` |
| Shared (talk first) | `detector.py snd_core.py analytics.py api.py main.py server_stdlib.py config.py run.py tests/ docs/` |

Rules: 1) edit only your own files; 2) work on your own branch (`ghand/...`, `seba/...`); 3) `git pull` first, commit small, merge by pull request;
4) tell the other person when an API field changes; 5) run `python -m unittest discover -s tests` before every push.
