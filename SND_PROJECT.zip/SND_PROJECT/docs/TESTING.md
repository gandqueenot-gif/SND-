# Testing
Run: `python -m unittest discover -s tests -v` (standard library only).

| File | Covers |
|---|---|
| test_decision_engine.py (9) | weight validation, best alternative, failed never chosen, current not selected, degraded penalty, weights change outcome, score bounds, min score |
| test_detector.py (6) | classification, thresholds, blip reset, recovery |
| test_workflow.py (12) | all scenarios end-to-end on real SQLite: detect -> decide -> failover -> recover -> failback, total outage, cascading, manual inject/recover, weights, restart persistence, reset, analytics |
| test_api.py (10) | every endpoint over a live HTTP server, 400/404/405 errors, malformed JSON, static files + path traversal, every endpoint used by app.js exists |

**Last recorded run (authoring sandbox, Python 3.12): 37 tests, 0 failures.**

## Not tested
- `backend/main.py` (FastAPI): sandbox had no FastAPI. Verify with `python run.py` then open `/api/health`.
- The dashboard was NOT opened in a real browser: JS syntax checked with `node --check`, file serving and all endpoints it calls were tested, but visual layout on iPad is unverified.
- One manual launcher smoke test with `python run.py --stdlib`: autorun detected a crash and failed over.
