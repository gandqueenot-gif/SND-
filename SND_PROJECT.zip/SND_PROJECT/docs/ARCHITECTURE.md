# Architecture
```
Browser (frontend/) --HTTP/JSON polling 1.5 s--> /api/*  (backend/api.py, framework-independent Router)
                                   FastAPI adapter (main.py)  or  stdlib adapter (server_stdlib.py)
                                                     v
                                          SND orchestrator (snd_core.py)
 Simulator -> probes -> FailureDetector -> transitions -> Decision engine -> Failover -> Recovery
(simulation.py)        (detector.py)                     (decision_engine.py)
                                                     v
          SQLite (database.py): events, decisions, failovers, recoveries, metrics, ticks, state -> analytics.py
```
| Requirement | Where |
|---|---|
| Infrastructure monitoring | `simulation.Infrastructure.step` (probes) + `detector` |
| Failure detection | `detector.FailureDetector`: 2 failed checks = failed; 2 slow = degraded; 2 good = recovered |
| Data collection & analysis | `metrics`/`ticks` tables, `snd_core.metrics_series`, `analytics.compute` |
| Decision engine | `decision_engine.evaluate`: weights over latency, load, reliability, cost, health; failed servers excluded; min score 0.30 |
| Failover simulation | `snd_core._execute_failover` (simulated switch time = 150 + 4*latency + 2*load ms) |
| Recovery management | recovery records, standby pool, planned failback to preferred primary A (cooldown 5 ticks, tolerance 0.05) |
| Event logging | `events` table; every stage logs |
| Performance analytics | MTTD, MTTR, success rate, availability, per-server uptime, decision time |

Design notes: 1 tick = 1 simulated second; non-active candidates are scored with +15% projected load;
repeated "retained"/"no alternative" decisions are not re-logged; all endpoints live in `api.py` and the two
HTTP adapters only translate requests.

Endpoints: GET `/api/health /status /scenarios /events /decisions /decisions/latest /failovers /recoveries /analytics /metrics /weights`;
POST `/api/tick /autorun /scenarios/run /inject /servers/{id}/recover /reset /evaluate`; PUT `/api/weights`.
