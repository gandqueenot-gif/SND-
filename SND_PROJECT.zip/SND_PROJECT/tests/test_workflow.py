"""End-to-end simulation workflow tests against a real SND instance + real SQLite file."""
import os
import tempfile
import unittest

from backend.snd_core import SND


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "t.db")
        self.snd = SND(self.path, seed=7)
        self.snd.advance(3)

    def tearDown(self):
        self.snd.db.close(); self.tmp.cleanup()

    def msgs(self):
        return [e["message"] for e in self.snd.db.events(500)]

    def test_baseline_is_stable(self):
        self.snd.advance(30)
        self.assertEqual(self.snd.active, "A")
        self.assertEqual(self.snd.db.failovers(), [])
        self.assertTrue(all(s["status"] == "healthy" for s in self.snd.status()["servers"]))

    def test_crash_detect_decide_failover_recover_failback(self):
        self.snd.run_scenario("active_crash")
        self.snd.advance(2)  # fault begins, 2 failed checks
        self.assertNotEqual(self.snd.active, "A", "should have failed over after detection")
        fo = self.snd.db.failovers()[-1]
        self.assertEqual((fo["from_server"], fo["trigger"], fo["success"]), ("A", "active_failed", 1))
        self.assertEqual(fo["ttd_s"], 1.0)
        d = self.snd.db.decisions(1)[0]
        self.assertEqual(d["selected"], self.snd.active)
        self.assertEqual(len(d["ranking"]), 3)
        self.assertEqual(d["ranking"][0]["server"], d["selected"])  # engine picked top-ranked alternative
        self.snd.advance(40)
        self.assertEqual(self.snd.active, "A", "planned failback to preferred primary")
        self.assertEqual(len(self.snd.db.recoveries()), 1)
        triggers = [f["trigger"] for f in self.snd.db.failovers()]
        self.assertIn("failback", triggers)
        m = self.msgs()
        self.assertTrue(any("FAILURE DETECTED" in x for x in m))
        self.assertTrue(any("RECOVERED" in x for x in m))

    def test_latency_spike_causes_degraded_failover(self):
        self.snd.run_scenario("latency_spike"); self.snd.advance(3)
        self.assertNotEqual(self.snd.active, "A")
        self.assertEqual(self.snd.db.failovers()[-1]["trigger"], "active_degraded")

    def test_overload_and_partition(self):
        for name in ("overload", "network_partition"):
            s = SND(":memory:", seed=3); s.advance(3); s.run_scenario(name); s.advance(3)
            self.assertNotEqual(s.active, "A", name)

    def test_degraded_standby_prefers_healthy_C(self):
        self.snd.run_scenario("degraded_standby"); self.snd.advance(3)
        self.assertEqual(self.snd.active, "C")
        rank = {e["server"]: e for e in self.snd.db.decisions(1)[0]["ranking"]}
        self.assertEqual(rank["B"]["status"], "degraded")
        self.assertGreater(rank["C"]["score"], rank["B"]["score"])

    def test_cascading_failure_ends_on_C(self):
        self.snd.run_scenario("cascading_failure"); self.snd.advance(12)
        self.assertEqual(self.snd.active, "C")
        tos = [f["to_server"] for f in reversed(self.snd.db.failovers())]  # oldest first
        self.assertEqual(tos[:2], ["B", "C"])

    def test_total_outage_then_restoration(self):
        self.snd.run_scenario("total_outage"); self.snd.advance(4)
        self.assertIsNone(self.snd.active)
        self.assertEqual(self.snd.status()["service_state"], "OUTAGE")
        self.assertEqual(self.snd.db.decisions(1)[0]["outcome"], "no_alternative")
        self.snd.advance(14)
        self.assertIsNotNone(self.snd.active)
        a = self.snd.analytics()
        self.assertLess(a["service_availability_pct"], 100)
        self.assertGreater(a["mttr_s"], 5)

    def test_manual_inject_and_manual_recover(self):
        self.snd.inject("A", "crash"); self.snd.advance(3)
        self.assertNotEqual(self.snd.active, "A")
        self.assertTrue(self.snd.recover_server("A")); self.snd.advance(12)
        self.assertEqual(self.snd.status()["servers"][0]["status"], "healthy")

    def test_changing_weights_is_persisted_and_used(self):
        self.snd.set_weights({"latency": 0, "load": 0, "reliability": 0, "cost": 1, "health": 0})
        self.snd.run_scenario("active_crash"); self.snd.advance(2)
        self.assertEqual(self.snd.active, "C", "cost-only weights should pick the cheapest server")
        self.assertAlmostEqual(self.snd.db.get_state("weights")["cost"], 1.0)

    def test_persistence_across_restart(self):
        self.snd.run_scenario("active_crash"); self.snd.advance(3)
        t, active, n = self.snd.tick_no, self.snd.active, len(self.snd.db.failovers())
        self.snd.db.close()
        s2 = SND(self.path, seed=7)
        self.assertEqual((s2.tick_no, s2.active, len(s2.db.failovers())), (t, active, n))
        self.snd = s2

    def test_reset_clears_everything(self):
        self.snd.run_scenario("active_crash"); self.snd.advance(3); self.snd.reset()
        self.assertEqual((self.snd.tick_no, self.snd.active, self.snd.db.failovers()), (0, "A", []))

    def test_analytics_fields(self):
        self.snd.run_scenario("active_crash"); self.snd.advance(30)
        a = self.snd.analytics()
        self.assertEqual(a["mttd_s"], 1.0)
        self.assertEqual(a["failover_success_rate_pct"], 100.0)
        self.assertEqual(set(a["per_server"]), {"A", "B", "C"})
        self.assertGreater(a["avg_decision_ms"], 0)


if __name__ == "__main__":
    unittest.main()
