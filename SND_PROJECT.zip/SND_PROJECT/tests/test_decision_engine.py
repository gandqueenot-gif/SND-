import unittest
from backend import decision_engine as de


def cand(i, status="healthy", lat=30.0, load=40.0, rel=0.97, cost=0.7, up=1.0):
    return {"id": i, "name": "Server " + i, "status": status, "latency_ms": lat,
            "load_pct": load, "reliability": rel, "cost": cost, "recent_uptime": up}


class DecisionEngineTests(unittest.TestCase):
    def test_weights_normalise_to_one(self):
        w = de.normalize_weights({"latency": 2, "load": 2, "reliability": 2, "cost": 2, "health": 2})
        self.assertAlmostEqual(sum(w.values()), 1.0, places=5)
        self.assertAlmostEqual(w["latency"], 0.2, places=5)

    def test_invalid_weights_rejected(self):
        for bad in ({"latency": 1}, {"latency": -1, "load": 1, "reliability": 1, "cost": 1, "health": 1},
                    {k: 0 for k in de.CRITERIA}, {"latency": "x", "load": 1, "reliability": 1, "cost": 1, "health": 1}, "nope"):
            with self.assertRaises(ValueError):
                de.normalize_weights(bad)

    def test_best_available_alternative_selected(self):
        r = de.evaluate([cand("A", "failed", None), cand("B", lat=40), cand("C", lat=200, load=80)], current="A")
        self.assertEqual(r["selected"], "B")
        self.assertGreater(r["ranking"][0]["score"], r["ranking"][1]["score"])

    def test_failed_server_never_selected(self):
        r = de.evaluate([cand("A"), cand("B", "failed", None), cand("C", "failed", None)], current="A")
        self.assertIsNone(r["selected"])
        self.assertFalse(next(e for e in r["ranking"] if e["server"] == "B")["eligible"])

    def test_current_server_is_scored_but_not_selected(self):
        r = de.evaluate([cand("A", lat=5, load=5), cand("B", lat=300, load=80, cost=1.4)], current="A")
        self.assertEqual(r["ranking"][0]["server"], "A")
        self.assertEqual(r["selected"], "B")

    def test_degraded_penalised_vs_healthy(self):
        r = de.evaluate([cand("A", "failed", None), cand("B", "degraded", lat=60), cand("C", "healthy", lat=60)], current="A")
        self.assertEqual(r["selected"], "C")

    def test_weights_change_the_decision(self):
        fast_costly = cand("B", lat=10, cost=1.4)
        slow_cheap = cand("C", lat=300, cost=0.2)
        base = {"A": cand("A", "failed", None)}
        lat_heavy = {"latency": 1, "load": 0, "reliability": 0, "cost": 0, "health": 0}
        cost_heavy = {"latency": 0, "load": 0, "reliability": 0, "cost": 1, "health": 0}
        self.assertEqual(de.evaluate([base["A"], fast_costly, slow_cheap], lat_heavy, "A")["selected"], "B")
        self.assertEqual(de.evaluate([base["A"], fast_costly, slow_cheap], cost_heavy, "A")["selected"], "C")

    def test_scores_bounded_and_contributions_sum(self):
        r = de.evaluate([cand("A"), cand("B")])
        for e in r["ranking"]:
            self.assertTrue(0 <= e["score"] <= 1)
            self.assertAlmostEqual(e["score"], sum(v["contribution"] for v in e["criteria"].values()), places=3)

    def test_min_score_threshold(self):
        r = de.evaluate([cand("A", "failed", None), cand("B", "degraded", lat=490, load=99, cost=1.5, rel=0.9, up=0.0)],
                        current="A", min_score=0.5)
        self.assertIsNone(r["selected"])


if __name__ == "__main__":
    unittest.main()
