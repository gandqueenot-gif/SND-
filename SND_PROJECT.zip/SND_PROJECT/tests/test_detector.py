import unittest
from backend.detector import FailureDetector, classify


def probe(up=True, lat=30.0, load=40.0):
    return {"server": "A", "up": up, "latency_ms": lat if up else None, "load_pct": load}


class DetectorTests(unittest.TestCase):
    def setUp(self):
        self.d = FailureDetector(["A"])

    def feed(self, tick, p):
        return self.d.observe(tick, {"A": p})

    def test_classification(self):
        self.assertEqual(classify(probe()), "ok")
        self.assertEqual(classify(probe(lat=400)), "degraded")
        self.assertEqual(classify(probe(load=95)), "degraded")
        self.assertEqual(classify(probe(up=False)), "fail")

    def test_single_missed_check_is_not_failure(self):
        out = self.feed(1, probe(up=False))
        self.assertEqual(self.d.health["A"].status, "healthy")
        self.assertEqual(out[0]["kind"], "suspect")

    def test_two_missed_checks_mark_failed(self):
        self.feed(1, probe(up=False))
        out = self.feed(2, probe(up=False))
        self.assertEqual(self.d.health["A"].status, "failed")
        self.assertTrue(any(o["kind"] == "transition" and o["to"] == "failed" for o in out))

    def test_blip_resets_counter(self):
        self.feed(1, probe(up=False)); self.feed(2, probe())
        self.feed(3, probe(up=False))
        self.assertEqual(self.d.health["A"].status, "healthy")

    def test_degraded_then_recovers(self):
        self.feed(1, probe(lat=500)); self.feed(2, probe(lat=500))
        self.assertEqual(self.d.health["A"].status, "degraded")
        self.feed(3, probe()); self.feed(4, probe())
        self.assertEqual(self.d.health["A"].status, "healthy")

    def test_failed_recovers_after_good_checks(self):
        self.feed(1, probe(up=False)); self.feed(2, probe(up=False))
        self.feed(3, probe())
        self.assertEqual(self.d.health["A"].status, "failed")
        out = self.feed(4, probe())
        self.assertEqual(self.d.health["A"].status, "healthy")
        self.assertTrue(any(o.get("to") == "healthy" for o in out))


if __name__ == "__main__":
    unittest.main()
