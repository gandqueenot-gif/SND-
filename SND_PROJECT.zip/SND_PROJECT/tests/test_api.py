"""Tests every HTTP endpoint over a REAL running server (stdlib adapter) with a temp DB."""
import json
import os
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

from backend.server_stdlib import make_server
from backend.snd_core import SND


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.snd = SND(os.path.join(cls.tmp.name, "api.db"), seed=11)
        cls.srv = make_server(cls.snd, "127.0.0.1", 0)
        cls.base = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown(); cls.srv.server_close(); cls.snd.db.close(); cls.tmp.cleanup()

    def call(self, method, path, body=None, raw=False):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method,
                                     headers={"Content-Type": "application/json"} if data else {})
        try:
            with urllib.request.urlopen(req) as r:
                payload = r.read()
                return r.status, (payload if raw else json.loads(payload))
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def test_01_health_and_status(self):
        self.call("POST", "/api/reset", {})
        s, d = self.call("GET", "/api/health"); self.assertEqual((s, d["ok"], d["simulation"]), (200, True, True))
        s, d = self.call("GET", "/api/status")
        self.assertEqual([x["id"] for x in d["servers"]], ["A", "B", "C"])
        self.assertEqual(d["service_state"], "OPERATIONAL"); self.assertTrue(d["simulation"])

    def test_02_scenarios_list(self):
        s, d = self.call("GET", "/api/scenarios")
        self.assertEqual(s, 200); self.assertGreaterEqual(len(d["scenarios"]), 7)
        self.assertIn("crash", d["fault_types"])

    def test_03_full_failure_workflow_over_http(self):
        self.call("POST", "/api/reset", {})
        self.call("POST", "/api/tick", {"n": 3})
        s, d = self.call("POST", "/api/scenarios/run", {"scenario": "active_crash"}); self.assertEqual(s, 200)
        s, d = self.call("POST", "/api/tick", {"n": 2}); self.assertEqual(s, 200)
        self.assertNotEqual(d["status"]["active"], "A")
        s, d = self.call("GET", "/api/decisions/latest")
        dec = d["decision"]; self.assertEqual(dec["outcome"], "failover"); self.assertEqual(len(dec["ranking"]), 3)
        self.assertEqual(dec["ranking"][0]["server"], dec["selected"])
        s, d = self.call("GET", "/api/failovers"); self.assertEqual(d["failovers"][0]["from_server"], "A")
        s, d = self.call("GET", "/api/events?level=critical"); self.assertTrue(any("FAILURE DETECTED" in e["message"] for e in d["events"]))
        s, d = self.call("GET", "/api/events?limit=5&category=failover"); self.assertEqual(s, 200)
        self.call("POST", "/api/tick", {"n": 40})
        s, d = self.call("GET", "/api/recoveries"); self.assertEqual(len(d["recoveries"]), 1)
        s, d = self.call("GET", "/api/analytics")
        self.assertEqual(d["mttd_s"], 1.0); self.assertGreaterEqual(d["failovers_total"], 2)
        s, d = self.call("GET", "/api/decisions?limit=3"); self.assertEqual(s, 200); self.assertLessEqual(len(d["decisions"]), 3)

    def test_04_metrics_series(self):
        self.call("POST", "/api/tick", {"n": 3})
        s, d = self.call("GET", "/api/metrics?ticks=10")
        self.assertEqual(s, 200); self.assertTrue(0 < len(d["ticks"]) <= 10)
        self.assertEqual(len(d["series"]["A"]["latency"]), len(d["ticks"]))

    def test_05_inject_recover_autorun(self):
        self.call("POST", "/api/reset", {})
        s, d = self.call("POST", "/api/inject", {"server": "B", "fault": "latency", "ttl": 5}); self.assertEqual(s, 200)
        self.call("POST", "/api/tick", {"n": 3})
        s, d = self.call("GET", "/api/status")
        self.assertEqual(next(x for x in d["servers"] if x["id"] == "B")["status"], "degraded")
        s, d = self.call("POST", "/api/servers/B/recover", {}); self.assertEqual((s, d["fault_cleared"]), (200, True))
        s, d = self.call("POST", "/api/autorun", {"enabled": True}); self.assertEqual((s, d["autorun"]), (200, True))
        self.call("POST", "/api/autorun", {"enabled": False})

    def test_06_weights_and_evaluate(self):
        s, d = self.call("GET", "/api/weights"); self.assertAlmostEqual(sum(d["weights"].values()), 1.0, places=3)
        s, d = self.call("PUT", "/api/weights", {"weights": {"latency": 5, "load": 1, "reliability": 1, "cost": 1, "health": 1}})
        self.assertEqual(s, 200); self.assertAlmostEqual(d["weights"]["latency"], 5 / 9, places=3)
        s, d = self.call("POST", "/api/evaluate", {}); self.assertEqual(s, 200)
        self.assertIn("ranking", d); self.assertIn("explanation", d)

    def test_07_validation_and_errors(self):
        self.assertEqual(self.call("POST", "/api/scenarios/run", {"scenario": "nope"})[0], 404)
        self.assertEqual(self.call("POST", "/api/inject", {"server": "Z", "fault": "crash"})[0], 400)
        self.assertEqual(self.call("POST", "/api/inject", {"server": "A", "fault": "meteor"})[0], 400)
        self.assertEqual(self.call("POST", "/api/inject", {"server": "A", "fault": "crash", "ttl": -2})[0], 400)
        self.assertEqual(self.call("POST", "/api/tick", {"n": 9999})[0], 400)
        self.assertEqual(self.call("POST", "/api/autorun", {"enabled": "yes"})[0], 400)
        self.assertEqual(self.call("PUT", "/api/weights", {"weights": {"latency": -1}})[0], 400)
        self.assertEqual(self.call("POST", "/api/servers/Q/recover", {})[0], 404)
        self.assertEqual(self.call("GET", "/api/events?limit=abc")[0], 400)
        self.assertEqual(self.call("GET", "/api/nothing")[0], 404)
        self.assertEqual(self.call("DELETE", "/api/status")[0] if False else self.call("POST", "/api/status", {})[0], 405)

    def test_08_malformed_json(self):
        req = urllib.request.Request(self.base + "/api/tick", data=b"{bad", method="POST",
                                     headers={"Content-Type": "application/json"})
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(req)
        self.assertEqual(cm.exception.code, 400)

    def test_09_dashboard_static_files_served(self):
        for path, needle in (("/", b"SND"), ("/app.js", b"/api/status"), ("/style.css", b"--bg")):
            s, d = self.call("GET", path, raw=True)
            self.assertEqual(s, 200); self.assertIn(needle, d)
        self.assertEqual(self.call("GET", "/../backend/config.py")[0], 404)

    def test_10_frontend_endpoints_all_exist(self):
        """Every /api path referenced in app.js must be a real route."""
        import re
        with open(os.path.join(os.path.dirname(__file__), "..", "frontend", "app.js")) as f:
            js = f.read()
        paths = set(re.findall(r'"(/api/[a-z/]+)', js))
        paths.discard("/api/servers/")
        paths.add("/api/servers/A/recover")
        self.assertGreaterEqual(len(paths), 8)
        for p in paths:
            p = p.rstrip("/")
            status = [self.call(m, p, {} if m != "GET" else None)[0] for m in ("GET", "POST", "PUT")]
            self.assertTrue(any(s != 404 for s in status), "frontend uses missing endpoint " + p)


if __name__ == "__main__":
    unittest.main()
